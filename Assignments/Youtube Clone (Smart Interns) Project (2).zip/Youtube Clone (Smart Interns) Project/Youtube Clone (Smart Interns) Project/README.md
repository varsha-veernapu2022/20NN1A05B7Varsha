
This is YouTube clone created using React.js for educational purposes.

## A copy of YouTube

- This is a clone of YouTube app
- Populated videos from RapidAPI
- Created using Material UI components

## Tech/framework used

- React.js
- Material UI
- RapidAPI

## Starting the project

Open the [.env.local.example](/.env.local.example) and fill in your Rapid API Key of Youtube V3 API which you can get from [here](https://rapidapi.com/ytdlfree/api/youtube-v31/) then save it as .env.local the run the following command:

```bash
npm install
npm run dev
```


## Screenshots

#### Video Feed

![Video Feed](/screenshots/screenshot-1.png)

#### Channel Page

![Channel Page](/screenshots/screenshot-2.png)

#### Search Result

![Search Result](/screenshots/screenshot-3.png)

#### Video Player

![Video Player](/screenshots/screenshot-4.png)
